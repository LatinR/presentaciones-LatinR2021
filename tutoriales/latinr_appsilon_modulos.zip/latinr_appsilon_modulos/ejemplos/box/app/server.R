server <- function(input, output, session) {
  texto$server("nombre")
  texto$server("apellido")
}